﻿from enum import Enum

class MouseKey(Enum):
    """마우스 버튼 목록"""
    Left = 1
    """왼쪽"""
    Middle = 2
    """중간 (마우스 휠)"""
    Right = 3
    """오른쪽"""

from JyunrcaeaFramework import MouseKey;
